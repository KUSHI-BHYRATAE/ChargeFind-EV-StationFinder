import csv
import threading
import time
from pathlib import Path
from typing import Any

from fastapi import FastAPI
from pydantic import BaseModel, Field

from src.data_loader import load_stations
from src.kd_tree import KDTree


ROOT = Path(__file__).resolve().parent
DATASET = ROOT / "data" / "india_ev_stations.csv"
if not DATASET.is_file() or DATASET.stat().st_size == 0:
    raise RuntimeError(f"ChargeFind dataset is missing or empty: {DATASET}")

STATIONS = load_stations(str(DATASET))
TREE = KDTree(STATIONS)
SEARCH_LOCK = threading.Lock()


def _optional_int(value: str | None) -> int | None:
    if not value:
        return None
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return None


def _optional_float(value: str | None) -> float | None:
    if not value:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _optional_bool(value: str | None) -> bool | None:
    if value is None or not value.strip():
        return None
    normalized = value.strip().lower()
    if normalized in {"true", "1", "yes"}:
        return True
    if normalized in {"false", "0", "no"}:
        return False
    return None


with DATASET.open("r", encoding="utf-8-sig", newline="") as csv_file:
    DATA_ROWS = list(csv.DictReader(csv_file))


def _station_record(row: dict[str, str]) -> dict[str, Any]:
    return {
        "stationId": row.get("station_id") or "",
        "name": row.get("name") or "Unnamed charging station",
        "city": row.get("city") or "",
        "stateProvince": row.get("state_province") or "",
        "latitude": float(row["latitude"]),
        "longitude": float(row["longitude"]),
        "ports": _optional_int(row.get("ports")),
        "powerKw": _optional_float(row.get("power_kw")),
        "powerClass": row.get("power_class") or None,
        "isFastDc": _optional_bool(row.get("is_fast_dc")),
        # The supplied dataset has no connector-type or live-availability fields.
        "connectorType": None,
        "availability": None,
    }


RECORDS = [_station_record(row) for row in DATA_ROWS]
RECORDS_BY_ID = {record["stationId"]: record for record in RECORDS}


class SearchInput(BaseModel):
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)
    k: int = Field(ge=1, le=10)


app = FastAPI(title="ChargeFind Spatial API", version="1.0.0")


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/overview")
def overview() -> dict[str, Any]:
    cities = {record["city"].strip().lower() for record in RECORDS if record["city"].strip()}
    states = {
        record["stateProvince"].strip().lower()
        for record in RECORDS
        if record["stateProvince"].strip()
    }
    return {
        "stationCount": len(STATIONS),
        "cityCount": len(cities),
        "stateCount": len(states),
        "datasetName": "india_ev_stations.csv",
        "unavailableFields": ["Connector type", "Live availability"],
    }


@app.get("/stations")
def stations() -> dict[str, Any]:
    return {"stations": RECORDS, "count": len(RECORDS)}


@app.post("/search")
def search(query: SearchInput) -> dict[str, Any]:
    start = time.perf_counter()
    with SEARCH_LOCK:
        nearest = TREE.nearest_neighbors(
            query.latitude,
            query.longitude,
            k=min(query.k, len(STATIONS)),
        )
        nodes_visited = TREE.nodes_visited
        branches_pruned = TREE.nodes_pruned
        elapsed_ms = (time.perf_counter() - start) * 1000

    results = []
    for rank, (distance, station) in enumerate(nearest, start=1):
        record = RECORDS_BY_ID.get(str(station.station_id))
        if record is None:
            continue
        results.append({**record, "distanceKm": distance, "rank": rank})

    return {
        "latitude": query.latitude,
        "longitude": query.longitude,
        "requestedK": query.k,
        "results": results,
        "analytics": {
            "nodesVisited": nodes_visited,
            "branchesPruned": branches_pruned,
            "searchTimeMs": elapsed_ms,
        },
    }